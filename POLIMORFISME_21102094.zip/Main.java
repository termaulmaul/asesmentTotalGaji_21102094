package com.maulana_rafi.pbo.asesmentTotalGaji;

public class Main {
    public Main() {
    }

    public static void main(String[] args) {
        new AssistenPraktikum_2094(
                "1003",
                "Rini",
                100000.0,
                "PBO",
                12
        );
        new StaffLab_2094(
                "1005",
                "Abdul",
                200000.0,
                "Pemrograman",
                4
        );
    }
}
