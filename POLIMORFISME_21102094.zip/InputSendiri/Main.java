package com.maulana_rafi.pbo.asesmentTotalGaji.InputSendiri;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("****Jumlah Data Asisten Praktikum: ");
        int numAsistenPraktikum = scanner.nextInt();
        List<AssistenPraktikum_2094> asistenPraktikumList = new ArrayList<>();
        for (int i = 0; i < numAsistenPraktikum; i++) {
            System.out.println("[Input Data Asisten Praktikum Ke - " + (i + 1) + "]");
            System.out.print("NIM: ");
            String nim = scanner.next();
            System.out.print("Nama: ");
            String nama = scanner.next();
            System.out.print("Gaji Pokok: ");
            double gajiPokok = scanner.nextDouble();
            System.out.print("Mata Kuliah: ");
            String mataKuliah = scanner.next();
            System.out.print("Jumlah Pertemuan: ");
            int jmlPertemuan = scanner.nextInt();

            AssistenPraktikum_2094 asistenPraktikum = new AssistenPraktikum_2094(nim, nama, gajiPokok, mataKuliah, jmlPertemuan);
            asistenPraktikumList.add(asistenPraktikum);
        }

        System.out.print("****Jumlah Data Staff Lab: ");
        int numStaffLab = scanner.nextInt();
        List<StaffLab_2094> staffLabList = new ArrayList<>();
        for (int i = 0; i < numStaffLab; i++) {
            System.out.println("[Input Data Staff Lab Ke - " + (i + 1) + "]");
            System.out.print("NIM: ");
            String nim = scanner.next();
            System.out.print("Nama: ");
            String nama = scanner.next();
            System.out.print("Gaji Pokok: ");
            double gajiPokok = scanner.nextDouble();
            System.out.print("Nama Lab: ");
            String namaLab = scanner.next();
            System.out.print("Jam Kerja: ");
            int jamKerja = scanner.nextInt();

            StaffLab_2094 staffLab = new StaffLab_2094(nama, nim, gajiPokok, namaLab, jamKerja);
            staffLabList.add(staffLab);
        }

        System.out.println("\n****Data Mahasiswa Bekerja****");
        for (AssistenPraktikum_2094 asistenPraktikum : asistenPraktikumList) {
            asistenPraktikum.hitungTotalGaji_2094();
        }

        for (StaffLab_2094 staffLab : staffLabList) {
            staffLab.hitungTotalGaji_2094();
        }
    }
}

